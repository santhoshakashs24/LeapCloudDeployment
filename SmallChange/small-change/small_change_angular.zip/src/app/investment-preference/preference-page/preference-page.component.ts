import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preference-page',
  templateUrl: './preference-page.component.html',
  styleUrls: ['./preference-page.component.css']
})
export class PreferencePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
