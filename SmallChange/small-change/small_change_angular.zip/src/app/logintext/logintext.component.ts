import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logintext',
  templateUrl: './logintext.component.html',
  styleUrls: ['./logintext.component.css']
})
export class LogintextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
