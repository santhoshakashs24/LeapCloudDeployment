export class InvestmentPreference {

  constructor(public investmentPurpose:string,
    public riskTolerance:string,
    public incomeCategory:string,
    public lengthOfInvestment:string){}
}
