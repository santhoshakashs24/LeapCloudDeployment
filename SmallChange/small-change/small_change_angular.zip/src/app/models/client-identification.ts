
export class ClientIdentification {
  constructor(public type:string,public value:string){}
}
