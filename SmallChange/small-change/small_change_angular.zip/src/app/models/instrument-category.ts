export class InstrumentCategory {
  constructor(public categoryId:string,
  public categoryName:string){}
}
