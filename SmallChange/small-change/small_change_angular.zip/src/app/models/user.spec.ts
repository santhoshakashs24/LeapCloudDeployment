import { User } from './user';

describe('User', () => {
  it('should create an instance', () => {
    //expect(new User(097867654,'dummy@gmail.com',new Date('1999-09-11'),'IN','560043','pass@#A','Dummy User',
    //[{type:'SSN',value:'87698765'}])).toBeTruthy();
  });
});
