import { InvestmentPreference } from './investment-preference';

describe('InvestmentPreference', () => {
  it('should create an instance', () => {
    expect(new InvestmentPreference('','','','')).toBeTruthy();
  });
});
